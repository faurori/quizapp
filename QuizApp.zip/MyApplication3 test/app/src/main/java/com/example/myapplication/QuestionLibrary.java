package com.example.myapplication;

public class QuestionLibrary {
//array for the questions
    public static String mQuestions[] = new String[]{
            "What division are the New York Rangers in?",
            "Which of the following are Goaltenders in the NHL?",
            "Who won the Stanley Cup in 2018?",
            "Which of the following were captains for the Rangers?",
            "Which is not an NHL team?"
    };
//the multiple choice answers/wrong answers
    public static String mChoices [][] = new String[][] {
            {"Pacific", "Atlantic", "Metropolitan", "Central"},
            {"Henrik Lundqvist", "Sidney Crosby", "Steven Stamkos", "John Tavares" },
            {"Pittsburg Penguins", "Tampa Bay Lightning", "Dallas Stars", "Washington Capitals"},
            {"Rick Nash", "Ryan McDonagh", "Chris Krieder", "Jaromir Jagr"},
            {"New Jersey Devils", "Boston Bruins", "Chicago Bulls", "Calgary Flames"}
    };
//answers
    public static String mAnswers[] = new String[] {"Metropolitan", "Henrik Lundqvist", "Washington Capitals", "Ryan McDonagh", "Chicago Bulls"};

    public String getQuestion(int a) {
        String question1 = mQuestions[a];
        return question1;
    }

    public String getChoice1(int a) {
        String choice0 = mChoices[a][0];
        return choice0;
}
    public String getChoice2(int a) {
        String choice1 = mChoices[a][1];
        return choice1;
    }
    public String getChoice3(int a) {
        String choice2 = mChoices[a][2];
        return choice2;
    }
    public String getChoice4(int a) {
        String choice3 = mChoices[a][3];
        return choice3;
    }
    public String getAnswers(int a) {
        String answer= mAnswers[a];
        return answer;
    }
}
