package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    private QuestionLibrary mQuestionLibrary = new QuestionLibrary();

    private TextView scoreView;
    private TextView questionView;
    private Button buttonChoice1;
    private Button buttonChoice2;
    private Button buttonChoice3;
    private Button buttonChoice4;

    private String mAnswer;
    private int mScore = 0;
    private int mQuestionNumber = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        scoreView = (TextView) findViewById(R.id.score);
        questionView = (TextView) findViewById(R.id.question1);
        buttonChoice1 = (Button) findViewById(R.id.choice1);
        buttonChoice2 = (Button) findViewById(R.id.choice2);
        buttonChoice3 = (Button) findViewById(R.id.choice3);
        buttonChoice4 = (Button) findViewById(R.id.choice4);

        updateQuestion();

        //choice one with question 1 will tell you if your right or wrong and go to next question
        buttonChoice1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (buttonChoice1.getText() == mAnswer) {
                    mScore = mScore + 1;
                    updateScore(mScore);


                    Toast.makeText(MainActivity.this, "Correct", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Incorrect", Toast.LENGTH_SHORT).show();

                }
                if (buttonChoice1.getText() == mAnswer) {
//if  answer is correct it will save to history tab
                    if (mQuestionNumber == QuestionLibrary.mQuestions.length) {
                        Intent history = new Intent(MainActivity.this, ScoreHistory.class);
                        Bundle bundle = new Bundle();
                        bundle.putInt("Final Score", mScore);
                        history.putExtras(bundle);
                        MainActivity.this.finish();
                        startActivity(history);
                    } else {
                        updateQuestion();
                    }
                }
                else{
                    if (mQuestionNumber == QuestionLibrary.mQuestions.length) {
                        Intent history = new Intent(MainActivity.this, ScoreHistory.class);
                        Bundle bundle = new Bundle();
                        bundle.putInt("Final Score", mScore);
                        history.putExtras(bundle);
                        MainActivity.this.finish();
                        startActivity(history);
                    } else {
                        updateQuestion();
                    }
                }
            }

        });

        buttonChoice2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (buttonChoice2.getText() == mAnswer) {
                    mScore = mScore + 1;
                    updateScore(mScore);


                    Toast.makeText(MainActivity.this, "Correct", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Incorrect", Toast.LENGTH_SHORT).show();

                }
                //if  answer is correct it will save to history tab
                if (buttonChoice2.getText() == mAnswer) {

                    if (mQuestionNumber == QuestionLibrary.mQuestions.length) {
                        Intent history = new Intent(MainActivity.this, ScoreHistory.class);
                        Bundle bundle = new Bundle();
                        bundle.putInt("Final Score", mScore);
                        history.putExtras(bundle);
                        MainActivity.this.finish();
                        startActivity(history);
                    } else {
                        updateQuestion();
                    }
                }
                else{
                    if (mQuestionNumber == QuestionLibrary.mQuestions.length) {
                        Intent history = new Intent(MainActivity.this, ScoreHistory.class);
                        Bundle bundle = new Bundle();
                        bundle.putInt("Final Score", mScore);
                        history.putExtras(bundle);
                        MainActivity.this.finish();
                        startActivity(history);
                    } else {
                        updateQuestion();
                    }
                }
            }

        });

        buttonChoice3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (buttonChoice3.getText() == mAnswer) {
                    mScore = mScore + 1;
                    updateScore(mScore);


                    Toast.makeText(MainActivity.this, "Correct", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Incorrect", Toast.LENGTH_SHORT).show();

                }
                if (buttonChoice3.getText() == mAnswer) {
//if  answer is correct it will save to history tab
                    if (mQuestionNumber == QuestionLibrary.mQuestions.length) {
                        Intent history = new Intent(MainActivity.this, ScoreHistory.class);
                        Bundle bundle = new Bundle();
                        bundle.putInt("Final Score", mScore);
                        history.putExtras(bundle);
                        MainActivity.this.finish();
                        startActivity(history);
                    } else {
                        updateQuestion();
                    }
                }
                else{
                    if (mQuestionNumber == QuestionLibrary.mQuestions.length) {
                        Intent history = new Intent(MainActivity.this, ScoreHistory.class);
                        Bundle bundle = new Bundle();
                        bundle.putInt("Final Score", mScore);
                        history.putExtras(bundle);
                        MainActivity.this.finish();
                        startActivity(history);
                    } else {
                        updateQuestion();
                    }
                }
            }

        });
        buttonChoice4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (buttonChoice4.getText() == mAnswer) {
                    mScore = mScore + 1;
                    updateScore(mScore);

                    Toast.makeText(MainActivity.this, "Correct", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Incorrect", Toast.LENGTH_SHORT).show();

                }
                if (buttonChoice4.getText() == mAnswer) {
//if  answer is correct it will save to history tab
                    if (mQuestionNumber == QuestionLibrary.mQuestions.length) {
                        Intent history = new Intent(MainActivity.this, ScoreHistory.class);
                        Bundle bundle = new Bundle();
                        bundle.putInt("Final Score", mScore);
                        history.putExtras(bundle);
                        MainActivity.this.finish();
                        startActivity(history);
                    } else {
                        updateQuestion();
                    }
                }
                else{
                    if (mQuestionNumber == QuestionLibrary.mQuestions.length) {
                        Intent history = new Intent(MainActivity.this, ScoreHistory.class);
                        Bundle bundle = new Bundle();
                        bundle.putInt("Final Score", mScore);
                        history.putExtras(bundle);
                        MainActivity.this.finish();
                        startActivity(history);
                    } else {
                        updateQuestion();
                    }
                }
            }

        });
    }


    private void updateQuestion() {
        questionView.setText(mQuestionLibrary.getQuestion(mQuestionNumber));
        buttonChoice1.setText(mQuestionLibrary.getChoice1(mQuestionNumber));
        buttonChoice2.setText(mQuestionLibrary.getChoice2(mQuestionNumber));
        buttonChoice3.setText(mQuestionLibrary.getChoice3(mQuestionNumber));
        buttonChoice4.setText(mQuestionLibrary.getChoice4(mQuestionNumber));

        mAnswer = mQuestionLibrary.getAnswers(mQuestionNumber);
        mQuestionNumber++;

    }

    private void updateScore(int point) {
        scoreView.setText("" + mScore);
    }
}


