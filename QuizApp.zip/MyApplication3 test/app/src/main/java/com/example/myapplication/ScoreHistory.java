package com.example.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class  ScoreHistory extends AppCompatActivity implements View.OnClickListener {

    TextView grade, highScore;
    Button tryAgain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score_history);

        grade = (TextView) findViewById(R.id.finalscore);
        highScore = (TextView) findViewById(R.id.highestscore);
        tryAgain = (Button) findViewById(R.id.bTryAgain);


        //Score from last test taken
        Bundle bundle = getIntent().getExtras();
        int score = bundle.getInt("Final Score");
        grade.setText("You scored a total of " + score + " out of " + QuestionLibrary.mQuestions.length);

        //Saving data on previous high scores
        SharedPreferences newPref = getPreferences(MODE_PRIVATE);
        int highestScore = newPref.getInt("Highest Score", 0);
        if (highestScore >= score)
            highScore.setText("High Score: " + highestScore);
        else {
            highScore.setText("New High Score: " + score);
            SharedPreferences.Editor newEditor = newPref.edit();
            newEditor.putInt("Highest Score", score);
            newEditor.commit();
        }
        tryAgain.setOnClickListener(this);
    }
    //clicking try again will bring you back to rules page to take quiz again
        @Override
        public void onClick (View v){
            switch (v.getId()) {
                case R.id.bTryAgain:
                    startActivity(new Intent(this, GameRules.class));
                    break;
            }
    }
}
